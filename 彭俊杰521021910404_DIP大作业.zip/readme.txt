
训练集&测试集——rps.zip所有文件
测试集——rps-test-set.zip 所有文件

传统方法
将test.py、rps.zip、rps-test-set.zip 放在同一目录
运行test.py即可


神经网络方法
将code5.py、rps.zip、rps-test-set.zip 放在同一目录
运行test.py即可